import axios from "axios";

export const postLogin = async () => {
  try {
    const res = await axios.post("주소", {});
    console.log(res.data);
  } catch (error) {
    console.log(error);
  }
};

export const getUser = async () => {
  try {
    const res = await axios.get("https://jsonplaceholder.typicode.com/todos/1");
    console.log(res.data);
    return res.data;
  } catch (error) {
    console.log(error);
  }
};
