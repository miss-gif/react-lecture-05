const App = () => {
  return (
    <div className="wrap container mx-auto bg-indigo-500 columns-3">
      <img
        className="w-full aspect-square"
        src="https://placehold.co/600x400"
      />
      <img
        className="w-full aspect-square"
        src="https://placehold.co/600x400"
      />
      <img
        className="w-full aspect-square"
        src="https://placehold.co/600x400"
      />
    </div>
  );
};

export default App;
