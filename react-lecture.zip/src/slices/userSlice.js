import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
// 규칙을 준수하시고 나중에 응용하세요.
// 1. AsyncThunk 객체를 만든다.
//  예) postLogin ===> const postLoginAsyncThunk
const getUserAsyncThunk = createAsyncThunk("getUserAsyncThunk");

const initialState = {
  userId: 0,
  id: 0,
  title: "",
  completed: false,
};
const userSlice = createSlice({
  name: "userSlice",
  initialState: initialState,
  // 앱에서 상태 업데이트 하기
  reducers: {
    showUser: (state, actions) => {
      console.log("정보를 보여줘");
    },
  },
  // 비동기로 API 서버 연동
  // builder 는 단어를 고치지 말자.
  extraReducers: builder => {
    builder.addCase();
  },
});
export const { showUser } = userSlice.actions;
export default userSlice.reducer;
