import React from "react";
import Menu from "./components/Menu";
import { useSelector } from "react-redux";

const RTKSample = () => {
  // slice 정보 가져오기
  const themeState = useSelector(state => state.themeSlice);
  //console.log(themeState); // {theme:"black"}
  // const colorObj = {
  //   color: themeState.theme,
  // };
  return (
    <div>
      <h1 style={{ color: themeState.theme }}>RTK 샘플</h1>
      <Menu />
    </div>
  );
};

export default RTKSample;
