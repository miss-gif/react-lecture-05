// 추후 export 할 자료 모양이므로
export interface UserInfo {
  id: string;
  age: number;
  isLogin: boolean;
}
