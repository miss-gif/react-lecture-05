import Chart from "./pages/Chart";

const AppChart: React.FC = () => {
  return <Chart />;
};

export default AppChart;
