export const WrapStyle = { backgroundColor: "red", fontSize: "12px" };
export const DivStyle = { backgroundColor: "red", fontSize: "12px" };
