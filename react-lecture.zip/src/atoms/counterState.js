import { atom } from "recoil";

// atom 만들기
export const counterState = atom({ key: "counterState", default: 0 });
