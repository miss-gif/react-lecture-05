import { atom } from "recoil";

export const userNameStae = atom({ key: "userNameStae", default: "" });
export const userEmailStae = atom({ key: "userEmailStae", default: "" });
export const userPasswrdStae = atom({ key: "userPasswrdStae", default: "" });
