export const Gallery = () => {
  return <div className="gallery"></div>;
};
