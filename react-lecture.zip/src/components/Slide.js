export const Slide = () => {
  return <div className="slide"></div>;
};
