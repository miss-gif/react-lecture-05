export const QuickLink = () => {
  return <div className="quicklink"></div>;
};
