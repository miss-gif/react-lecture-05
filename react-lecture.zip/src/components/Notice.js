export const Notice = () => {
  return <div className="notice"></div>;
};
