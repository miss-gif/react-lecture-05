export const Info = ({ children }) => {
  return <div className="info">{children}</div>;
};
