const Footer: React.FC = () => {
  return <footer className="header"></footer>;
};

export default Footer;
