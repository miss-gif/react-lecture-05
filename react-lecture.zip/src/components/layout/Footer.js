export const Footer = () => {
  return <footer className="footer"></footer>;
};
