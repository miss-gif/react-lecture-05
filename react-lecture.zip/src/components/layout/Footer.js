const Footer = () => {
  return <footer className="header"></footer>;
};

export default Footer;
