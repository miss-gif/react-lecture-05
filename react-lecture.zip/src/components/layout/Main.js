export const Main = ({ children }) => {
  return <main className="main">{children}</main>;
};
