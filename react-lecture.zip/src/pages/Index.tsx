import React from "react";

const Index: React.FC = () => {
  return <h1>홈페이지</h1>;
};

export default Index;
