import React, { useEffect, useState } from "react";

const MulitiFile = () => {
  // 입력항목
  const [title, setTitle] = useState("");
  const [dday, setDday] = useState("");
  // File 객체를 관리
  const [sendFiles, setSendFiles] = useState([]);
  // 이미지 미리보기 URL 관리
  const [previewFiles, setPreviewFiles] = useState([]);

  // 이미지 미리 보기 JSX 만들기 함수
  const makeThumbnail = () => {
    return previewFiles.map((item, index) => (
      <img
        src={item}
        key={index}
        style={{ width: 80 }}
        onClick={e => {
          deleteFile(index);
        }}
      />
    ));
  };

  // 파일 목록
  const handleFileChange = e => {
    // console.log(e.target.files);
    // 출력결과 FileList {0: File, 1: File, length: 2}
    // Array.from(객체) : 객체를 배열로 만듦
    const filesArr = Array.from(e.target.files);
    // 파일 보관
    setSendFiles([...sendFiles, ...filesArr]);
    // 미리보기 URL 보관
    const imgUrlArr = filesArr.map(item => URL.createObjectURL(item));
    setPreviewFiles([...previewFiles, ...imgUrlArr]);
    // filesArr.map(item => {
    //   return URL.createObjectURL(item);
    // });
    // filesArr.map(item => {
    //   const url = URL.createObjectURL(item);
    //   return url;
    // });
  };
  // 파일 목록에서 특정 항목 삭제
  const deleteFile = _index => {
    // console.log("삭제", _index);
    // 미리보기 배열에서 제거 : 기준 순서(index)
    const tempPreviewArr = previewFiles.filter(
      (item, index) => index !== _index,
    );
    setPreviewFiles(tempPreviewArr);
    // 전송 파일 배열에서 제거 : 기준 순서(index)
    const tempFileArr = sendFiles.filter((item, index) => index !== _index);
    setSendFiles(tempFileArr);
  };

  useEffect(() => {
    console.log(sendFiles);
    console.log(previewFiles);
  }, [sendFiles, previewFiles]);
  // 파일 전송
  const handleSubmit = e => {
    // 기본 기능 막기
    e.preventDefault();
  };
  return (
    <div style={{ width: "80%", margin: "0 auto" }}>
      <h1>멀티 파일 업로드</h1>
      <form onSubmit={e => handleSubmit(e)}>
        <fieldset>
          <legend>기본정보</legend>
          <label htmlFor="title">제목</label>
          <input
            type="text"
            id="title"
            value={title}
            onChange={e => setTitle(e.target.value)}
          />
          <label htmlFor="dday">D-day</label>
          <input
            type="date"
            id="dday"
            value={dday}
            onChange={e => setDday(e.target.value)}
          />
        </fieldset>
        <fieldset>
          <legend>파일정보</legend>
          <div>{makeThumbnail()}</div>
          <input
            type="file"
            accept="image/jpg, image/png, image/gif"
            multiple
            onChange={e => handleFileChange(e)}
          />
        </fieldset>
        <fieldset>
          <button type="submit">등록</button>
          <button type="reset">재작성</button>
        </fieldset>
      </form>
    </div>
  );
};

export default MulitiFile;
