import React from "react";

const Index = () => {
  return <h1>홈페이지</h1>;
};

export default Index;
