const History = ({ title, year }) => {
  return (
    <div>
      <h1>
        {title} {year} 연혁
      </h1>
    </div>
  );
};

export default History;
