const Index = () => {
  return <h1>회사소개</h1>;
};

export default Index;
