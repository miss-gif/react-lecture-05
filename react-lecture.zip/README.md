# nivo-chart ts

- /src/AppChart.js ===> /src/AppChart.tsx

```tsx
import Chart from "./pages/Chart";

const AppChart: React.FC = () => {
  return <Chart />;
};

export default AppChart;
```

- /src/pages/Chart.js ===> /src/Chart.tsx

## 1. data 는 외부로 별도 파일

- src/apis/data.tsx 생성
