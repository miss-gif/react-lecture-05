# axios TS버전

## 1. axios 설치(TS)

- `npm install axios`
- `npm install @types/axios`

## /src/apis/todos/apistodos.js

- 확장자 변경 (js ---> ts)
- `/src/apis/todos/apistodos.ts`
