# Context 이해

- 컴포넌트는 useState
- 앱서비스는 Context API

## 1. 적용단계

- /src/AppRoot.js 생성
